﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SQLite;
using System.Data;

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //New list for output to webpage
        var WebOutput = new List<string>();

        //Query SQLite database and display data

        using (System.Data.SQLite.SQLiteConnection con3 = new System.Data.SQLite.SQLiteConnection("data source=C:\\Users\\CJ\\Documents\\Visual Studio 2015\\GambitChallenge\\GambitChallenge\\bin\\x64\\Debug\\database.db3"))
        {
            using (System.Data.SQLite.SQLiteCommand com3 = new System.Data.SQLite.SQLiteCommand(con3))
            {
                con3.Open();                             // Open the connection to the database
                com3.CommandText = "Select * FROM RegisterData";      // Select all rows from our database table RegisterData

                using (System.Data.SQLite.SQLiteDataReader reader = com3.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        WebOutput.Add(reader["ID"] + " : " + reader["DATA"]);     // Add the value of the key and value columns for every row into list WebOutput
                                                                                  // Console.ReadKey();
                    }
                }
                con3.Close();        // Close the connection to the database
            }

        }

        //Bind data to GridView 
        GridView1.DataSource = WebOutput; 
        GridView1.DataBind();
    }
}


    
    
